# testDicom
库中的dicom文件配合InteractiveMedicalImages应用程序使用
#使用时将这个文件下载解压并修改 最外层文件名称为 testDICOM 放到 XAMMP 安装目录下的 htdocs 目录下就可以了

