# SDE文档如下：

## SDE对象本身的接口文档

1. [SDE初始化时的options文档](./sde.options.md)
2. [SDE实例接口文档](./sde.api.md)

## SDE控件文档：

1. [SDE控件文档](./sde.ctrl.api.md)