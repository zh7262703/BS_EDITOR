# sodiaoeditor-ie8-vue

当前使用SDE版本为v4.

## 修改项：

1. config/index.js 中新增proxyTable 进行数据模拟，因部分select控件的数据来自异步加载数据。后期会提供接口让该地址可配置。