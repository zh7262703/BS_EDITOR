window.onload = function() {
  this.console.log('editor load success!');
};